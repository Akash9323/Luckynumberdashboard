/* eslint-disable prettier/prettier */
export const gameData = [
   {
       game_id:'1',
       game_name:'Luckynumbers',
       game_date:'23 March ',
       game_time:'9 PM ',
       game_details_id :'23459 ',
   },
   {
    game_id:'2',
    game_name:'Luckynumbers',
    game_date:'25 June',
    game_time:'10 PM ',
    game_details_id :'24006 ',
},
{
    game_id:'3',
    game_name:'Luckynumbers',
    game_date:'23 March ',
    game_time:'9 PM ',
    game_details_id :'23458 ',
},
{
    game_id:'4',
    game_name:'Luckynumbers',
    game_date:'23 March ',
    game_time:'9 PM ',
    game_details_id :'23466 ',
},
{
    game_id:'5',
    game_name:'Luckynumbers',
    game_date:'23 Aug ',
    game_time:'11 PM ',
    game_details_id :'23456 ',
},
]